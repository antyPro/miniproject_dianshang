import { TdCheckTagProps } from './type';
declare const props: TdCheckTagProps;
export default props;
