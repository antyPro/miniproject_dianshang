import { TdCountDownProps } from './type';
declare const props: TdCountDownProps;
export default props;
