import { TdCollapseProps } from './type';
declare const props: TdCollapseProps;
export default props;
