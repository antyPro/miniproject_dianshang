import { TdNavbarProps } from './type';
declare const props: TdNavbarProps;
export default props;
