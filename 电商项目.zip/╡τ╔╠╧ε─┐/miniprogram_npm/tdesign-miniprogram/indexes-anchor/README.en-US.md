:: BASE_DOC ::

## API
### IndexesAnchor Props

name | type | default | description | required
-- | -- | -- | -- | --
external-classes | Array | - | `['t-class']` | N
index | String / Number | - | \- | N
